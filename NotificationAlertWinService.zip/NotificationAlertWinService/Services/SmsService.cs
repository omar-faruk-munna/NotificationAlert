﻿using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using NotificationAlertWinService.Models;
using NotificationAlertWinService.Repositories;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;

namespace NotificationAlertWinService.Services
{
    public class SmsService : ISmsRepository
    {
        #region Fields
        private readonly IHttpClientFactory _clientFactory;
        private readonly IConfiguration _configuration;
        private readonly ILogRepository _errorLog;
        private readonly string _apiMood;
        private readonly string _sslMood;
        private readonly string _toNumber;
        private readonly string _uflApiBaseUrl;
        private readonly string _uflApiKey;
        private readonly string _smsSuccessDir;
        private readonly string _smsFailDir;
        private readonly string _sslSmsUser;
        private readonly string _sslSmsPass;
        private readonly string _sslSmsSid;
        private readonly string _sslSmsUri;
        private readonly string _defaultProviderId;
        private readonly string _robiProviderApi;
        private readonly string _robiUserName;
        private readonly string _robiPass;
        private readonly string _robiMasking;
        private readonly string _blUserName;
        private readonly string _blPass;
        private readonly string _blMasking;
        private readonly string _blProviderApi;
        private readonly string _gpProviderApi;
        private readonly string _gpUserName;
        private readonly string _gpPass;
        private readonly string _gpMasking;
        private readonly string _bankName;

        #endregion

        public SmsService(IConfiguration configuration, ILogRepository errorLog, IHttpClientFactory clientFactory)
        {
            _clientFactory = clientFactory;
            _configuration = configuration;
            _errorLog = errorLog;
            _apiMood = _configuration.GetSection("API_ExecutionMode").GetSection("MODE").Value.ToUpper();
            _sslMood = _configuration.GetSection("SSL_SMS").GetSection("enable").Value.ToUpper();
            _toNumber = _configuration.GetSection("API_ExecutionMode").GetSection("MOBILE").Value;
            _uflApiBaseUrl = _configuration.GetSection("WebAPIBaseUrl").Value;
            _uflApiKey = _configuration.GetSection("ApiKey").Value;
            _smsSuccessDir = _configuration.GetSection("SmsSuccessDir").Value;
            _smsFailDir = _configuration.GetSection("SmsFailDir").Value;
            _sslSmsUser = _configuration.GetSection("SSL_SMS").GetSection("user").Value;
            _sslSmsPass = _configuration.GetSection("SSL_SMS").GetSection("pass").Value;
            _sslSmsSid = _configuration.GetSection("SSL_SMS").GetSection("sid").Value;
            _sslSmsUri = _configuration.GetSection("SSL_SMS").GetSection("URI").Value;
            _robiUserName = _configuration.GetSection("Robi").GetSection("USER_NAME_ROBI").Value;
            _robiPass = _configuration.GetSection("Robi").GetSection("PASSWORD_ROBI").Value;
            _robiMasking = _configuration.GetSection("Robi").GetSection("MASKING_ROBI").Value;
            _robiProviderApi = _configuration.GetSection("ProviderAPI").GetSection("ROBI_API").Value;
            _blUserName = _configuration.GetSection("Banglalink").GetSection("USER_NAME_BL").Value;
            _blPass = _configuration.GetSection("Banglalink").GetSection("PASSWORD_BL").Value;
            _blMasking = _configuration.GetSection("Banglalink").GetSection("MASKING_BL").Value;
            _blProviderApi = _configuration.GetSection("ProviderAPI").GetSection("BL_API").Value;
            _defaultProviderId = _configuration.GetSection("DefaultProvider").GetSection("DEFAULT_PROVIDER_ID").Value;
            _gpProviderApi = _configuration.GetSection("ProviderAPI").GetSection("GP_API").Value;
            _gpUserName = _configuration.GetSection("GrameenPhone").GetSection("USER_NAME_GP").Value;
            _gpPass = _configuration.GetSection("GrameenPhone").GetSection("PASSWORD_GP").Value;
            _gpMasking = _configuration.GetSection("GrameenPhone").GetSection("MASKING_GP").Value;
            this._bankName = _configuration.GetSection("BankName").Value;

        }

        private void SslApiWebClient(string smsContent, string toNumber, string accountNo)
        {
            //string myParameters =
            //    "user=" + user + 
            //    "&pass=" + pass +
            //    "&sms[0][0]=88" + mobileNo +                            //length 13
            //    "&sms[0][1]=" + System.Web.HttpUtility.UrlEncode(message) +
            //    "&sms[0][2]=" + DateTime.Now.ToString("yyyyMMddHHmmssfff") +
            //    "&sms[1][0]=88***********" +
            //    "&sms[1][1]=" + System.Web.HttpUtility.UrlEncode("TESTSMS2\nTESTSMS3") +
            //    "&sms[1][2]=" + "1234567890" +
            //    "&sid=" + sid;

            try
            {
                if (string.Equals(_apiMood, "UAT"))
                {
                    toNumber = _toNumber;
                }

                if (!string.IsNullOrEmpty(toNumber))
                {
                    if (toNumber.Length == 11)
                    {
                        string myParameters =
                                "user=" + _sslSmsUser +
                                "&pass=" + _sslSmsPass +
                                "&sms[0][0]=" + "88" + toNumber +
                                "&sms[0][1]=" + System.Web.HttpUtility.UrlEncode(smsContent) +
                                "&sms[0][2]=" + DateTime.Now.ToString("yyyyMMddHHmmssfff") +
                                "&sid=" + _sslSmsSid;

                        //string myParameters = $"user={ _user }&pass={ _pass }&msisdn=88{ toNumber }&sms={System.Web.HttpUtility.UrlEncode(smsContent)}&csmsid={DateTime.Now.ToString("yyyyMMddHHmmssfff")}&sid={_sid}";

                        SslSmsReply objReply;
                        string htmlResult;
                        using (WebClient wc = new WebClient())
                        {
                            wc.Headers[HttpRequestHeader.ContentType] = "application/x-www-form-urlencoded";
                            htmlResult = wc.UploadString(_sslSmsUri, myParameters);
                            XmlSerializer serializer = new XmlSerializer(typeof(SslSmsReply));
                            using TextReader reader = new StringReader(htmlResult);
                            objReply = (SslSmsReply)serializer.Deserialize(reader);
                        }

                        if (objReply.SMSINFO.Count == 0)
                        {
                            _errorLog.LogSmsFailed(_smsFailDir, "product id", accountNo, toNumber, smsContent, "Failed");
                        }
                        else
                        {
                            _errorLog.LogSmsSuccess(_smsSuccessDir, "product id", accountNo, toNumber, smsContent, "Success");
                        }
                    }
                    else if (toNumber.Length == 13)
                    {
                        string myParameters =
                                "user=" + _sslSmsUser +
                                "&pass=" + _sslSmsPass +
                                "&sms[0][0]=" + toNumber +
                                "&sms[0][1]=" + System.Web.HttpUtility.UrlEncode(smsContent) +
                                "&sms[0][2]=" + DateTime.Now.ToString("yyyyMMddHHmmssfff") +
                                "&sid=" + _sslSmsSid;

                        //string myParameters = $"user={ _user }&pass={ _pass }&msisdn=88{ toNumber }&sms={System.Web.HttpUtility.UrlEncode(smsContent)}&csmsid={DateTime.Now.ToString("yyyyMMddHHmmssfff")}&sid={_sid}";

                        SslSmsReply objReply;
                        string htmlResult;
                        using (WebClient wc = new WebClient())
                        {
                            wc.Headers[HttpRequestHeader.ContentType] = "application/x-www-form-urlencoded";
                            htmlResult = wc.UploadString(_sslSmsUri, myParameters);
                            XmlSerializer serializer = new XmlSerializer(typeof(SslSmsReply));
                            using TextReader reader = new StringReader(htmlResult);
                            objReply = (SslSmsReply)serializer.Deserialize(reader);
                        }

                        if (objReply.SMSINFO.Count == 0)
                        {
                            _errorLog.LogSmsFailed(_smsFailDir, "product id", accountNo, toNumber, smsContent, "Failed");
                        }
                        else
                        {
                            _errorLog.LogSmsSuccess(_smsSuccessDir, "product id", accountNo, toNumber, smsContent, "Success");
                        }
                    }
                }
                else
                {
                    _errorLog.LogSmsFailed(_smsFailDir, "product id", accountNo, toNumber, smsContent, "Failed");
                }
            }
            catch (Exception ex)
            {
                _errorLog.LogError(ex.Message);
            }
        }

        private async Task<Tuple<int, string>> SslApiHttpClientAsync(string smsContent, string toNumber, string accountNo)
        {
            try
            {
                if (string.Equals(_apiMood, "UAT"))
                {
                    toNumber = _toNumber;
                }

                if (!string.IsNullOrWhiteSpace(toNumber))
                {
                    if (toNumber.Length == 11)
                    {
                        string parameters = $"?user={_sslSmsUser}&pass={_sslSmsPass}&msisdn=88{toNumber}&sms={smsContent}&csmsid={DateTime.Now.ToString("yyyyMMddHHmmssfff")}&sid={_sslSmsSid}";
                        Uri uri = new Uri(_sslSmsUri + parameters);

                        HttpClient client = _clientFactory.CreateClient("SslClient");
                        HttpResponseMessage response = await client.PostAsync(uri, null);

                        string result = await response.Content.ReadAsStringAsync();
                        SslSmsReply objReply;
                        XmlSerializer serializer = new XmlSerializer(typeof(SslSmsReply));
                        using TextReader reader = new StringReader(result);
                        objReply = (SslSmsReply)serializer.Deserialize(reader);

                        if (objReply.SMSINFO.Count == 0)
                        {
                            _errorLog.LogSmsFailed(_smsFailDir, "product id", accountNo, toNumber, smsContent, "Failed, Parameter: " + objReply.PARAMETER + ", Login: " + objReply.LOGIN);

                            return new Tuple<int, string>(0, $"Parameter: {objReply.PARAMETER}, Login: {objReply.LOGIN}, PushApi: {objReply.PUSHAPI}, Stake Holder Id: {objReply.STAKEHOLDERID}, Permited: {objReply.PERMITTED}");
                        }
                        else
                        {
                            //_errorLog.LogSmsSuccess(_smsSuccessDir, "product id", accountNo, toNumber, smsContent, "Success");
                            _errorLog.LogSmsSuccess(_smsSuccessDir, "product id", accountNo, toNumber, smsContent, "Success");
                            return new Tuple<int, string>(1, "");
                        }
                    }
                    else
                    {
                        string parameters = $"?user={_sslSmsUser}&pass={_sslSmsPass}&msisdn={toNumber}&sms={smsContent}&csmsid={DateTime.Now.ToString("yyyyMMddHHmmssfff")}&sid={_sslSmsSid}";
                        var uri = new Uri(_sslSmsUri + parameters);

                        HttpClient client = _clientFactory.CreateClient("SslClient");
                        HttpResponseMessage response = await client.PostAsync(uri, null);
                        string result = await response.Content.ReadAsStringAsync();
                        SslSmsReply objReply;
                        XmlSerializer serializer = new XmlSerializer(typeof(SslSmsReply));
                        using TextReader reader = new StringReader(result);
                        objReply = (SslSmsReply)serializer.Deserialize(reader);

                        if (objReply.SMSINFO.Count == 0)
                        {
                            _errorLog.LogSmsFailed(_smsFailDir, "product id", accountNo, toNumber, smsContent, "Failed, " + objReply.PARAMETER + ", " + objReply.LOGIN);

                            return new Tuple<int, string>(0, $"Parameter: {objReply.PARAMETER}, Login: {objReply.LOGIN}, PushApi: {objReply.PUSHAPI}, Stake Holder Id: {objReply.STAKEHOLDERID}, Permited: {objReply.PERMITTED}");
                        }
                        else
                        {
                            //_errorLog.LogSmsSuccess(_smsSuccessDir, "product id", accountNo, toNumber, smsContent, "Success");
                            _errorLog.LogSmsSuccess(_smsSuccessDir, "product id", accountNo, toNumber, smsContent, "Success");
                            return new Tuple<int, string>(1, "");
                        }
                    }
                }
                else
                {
                    return new Tuple<int, string>(0, "Invalid Phone Number.");
                }
            }
            catch (Exception e)
            {
                _errorLog.LogError(e.Message);
                return new Tuple<int, string>(0, e.Message);
            }

        }

        //private async Task SslApiHttpClientAsync(string smsContent, string toNumber, string accountNo)
        //{
        //    try
        //    {
        //        if (string.Equals(_apiMood, "UAT"))
        //        {
        //            toNumber = _toNumber;
        //        }

        //        int numberLength = toNumber.Length;

        //        if (!string.IsNullOrEmpty(toNumber) && numberLength > 10)
        //        {
        //            if (numberLength == 11)
        //            {
        //                FormUrlEncodedContent stringContent = new FormUrlEncodedContent(new[]
        //                {
        //                    new KeyValuePair<string, string>("user", _sslSmsUser),
        //                    new KeyValuePair<string, string>("pass", _sslSmsPass),
        //                    new KeyValuePair<string, string>("sms[0][0]", $"88{toNumber}"),
        //                    new KeyValuePair<string, string>("sms[0][1]", smsContent),
        //                    new KeyValuePair<string, string>("sms[0][2]", DateTime.Now.ToString("yyyyMMddHHmmssfff")),
        //                    new KeyValuePair<string, string>("sid", _sslSmsSid)
        //                });

        //                //Uri uri = new Uri(_sslUri);
        //                HttpClient client = _clientFactory.CreateClient("SslClient");
        //                HttpResponseMessage response = await client.PostAsync(_sslSmsUri, stringContent);
        //                await Task.Delay(50);
        //                string result = await response.Content.ReadAsStringAsync();
        //                SslSmsReply objReply;
        //                XmlSerializer serializer = new XmlSerializer(typeof(SslSmsReply));
        //                using TextReader reader = new StringReader(result);
        //                objReply = (SslSmsReply)serializer.Deserialize(reader);

        //                if (objReply.SMSINFO.Count == 0)
        //                {
        //                    _errorLog.LogSmsFailTsv(_smsFailDir, _smsHeadFormat, toNumber, smsContent, accountNo, "Failed");
        //                }
        //                else
        //                {
        //                    _errorLog.LogSmsSuccessTsv(_smsSuccessDir, _smsHeadFormat, toNumber, smsContent, accountNo, "Success");
        //                }
        //            }
        //            else
        //            {
        //                if (toNumber.Contains("+"))
        //                {
        //                    string newNumber = toNumber.Substring(1);
        //                    numberLength = newNumber.Length;

        //                    if (numberLength == 13)
        //                    {
        //                        FormUrlEncodedContent stringContent = new FormUrlEncodedContent(new[]
        //                        {
        //                            new KeyValuePair<string, string>("user", _sslSmsUser),
        //                            new KeyValuePair<string, string>("pass", _sslSmsPass),
        //                            new KeyValuePair<string, string>("sms[0][0]", newNumber),
        //                            new KeyValuePair<string, string>("sms[0][1]", smsContent),
        //                            new KeyValuePair<string, string>("sms[0][2]", DateTime.Now.ToString("yyyyMMddHHmmssfff")),
        //                            new KeyValuePair<string, string>("sid", _sslSmsSid)
        //                        });

        //                        //Uri uri = new Uri(_sslUri);
        //                        HttpClient client = _clientFactory.CreateClient("SslClient");
        //                        HttpResponseMessage response = await client.PostAsync(_sslSmsUri, stringContent);
        //                        await Task.Delay(50);
        //                        string result = await response.Content.ReadAsStringAsync();
        //                        SslSmsReply objReply;
        //                        XmlSerializer serializer = new XmlSerializer(typeof(SslSmsReply));
        //                        using TextReader reader = new StringReader(result);
        //                        objReply = (SslSmsReply)serializer.Deserialize(reader);

        //                        if (objReply.SMSINFO.Count == 0)
        //                        {
        //                            _errorLog.LogSmsFailTsv(_smsFailDir, _smsHeadFormat, toNumber, smsContent, accountNo, "Failed");
        //                        }
        //                        else
        //                        {
        //                            _errorLog.LogSmsSuccessTsv(_smsSuccessDir, _smsHeadFormat, toNumber, smsContent, accountNo, "Success");
        //                        }
        //                    }
        //                    else
        //                    {
        //                        _errorLog.LogSmsFailTsv(_smsFailDir, _smsHeadFormat, toNumber, smsContent, accountNo, "Invalid Mobile Number");
        //                    }
        //                }
        //                else if (numberLength == 13)
        //                {
        //                    FormUrlEncodedContent stringContent = new FormUrlEncodedContent(new[]
        //                    {
        //                        new KeyValuePair<string, string>("user", _sslSmsUser),
        //                        new KeyValuePair<string, string>("pass", _sslSmsPass),
        //                        new KeyValuePair<string, string>("sms[0][0]", toNumber),
        //                        new KeyValuePair<string, string>("sms[0][1]", smsContent),
        //                        new KeyValuePair<string, string>("sms[0][2]", DateTime.Now.ToString("yyyyMMddHHmmssfff")),
        //                        new KeyValuePair<string, string>("sid", _sslSmsSid)
        //                    });

        //                    //Uri uri = new Uri(_sslUri);
        //                    HttpClient client = _clientFactory.CreateClient("SslClient");
        //                    HttpResponseMessage response = await client.PostAsync(_configuration.GetSection("SSL_SMS").GetSection("URI").Value, stringContent);
        //                    await Task.Delay(50);
        //                    string result = await response.Content.ReadAsStringAsync();
        //                    SslSmsReply objReply;
        //                    XmlSerializer serializer = new XmlSerializer(typeof(SslSmsReply));
        //                    using TextReader reader = new StringReader(result);
        //                    objReply = (SslSmsReply)serializer.Deserialize(reader);

        //                    if (objReply.SMSINFO.Count == 0)
        //                    {
        //                        _errorLog.LogSmsFailTsv(_smsFailDir, _smsHeadFormat, toNumber, smsContent, accountNo, "Failed");
        //                    }
        //                    else
        //                    {
        //                        _errorLog.LogSmsSuccessTsv(_smsSuccessDir, _smsHeadFormat, toNumber, smsContent, accountNo, "Success");
        //                    }
        //                }
        //            }
        //        }
        //        else
        //        {
        //            _errorLog.LogSmsFailTsv(_smsFailDir, _smsHeadFormat, toNumber, smsContent, accountNo, "Invalid Mobile Number");
        //        }
        //    }
        //    catch (Exception e)
        //    {
        //        _errorLog.LogError(e.Message).Wait();
        //    }
        //}

        private void RobiApi(string smsContent, string toNumber, string accountNo, out string error, out string response)
        {
            response = string.Empty;
            error = string.Empty;

            try
            {
                string url = _robiProviderApi + "?Username=" + _robiUserName + "&Password=" + _robiPass + "&From=" + _robiMasking + "&To=" + toNumber + "&Message=" + smsContent;
                using WebClient wc = new WebClient();
                string xml = wc.DownloadString(url);
                XmlDocument doc = new XmlDocument();
                doc.LoadXml(xml);
                XmlNodeList xnList = doc.GetElementsByTagName("ServiceClass");

                foreach (XmlNode xn in xnList)
                {
                    error = xn["ErrorCode"].InnerText;
                }
                response = (error == "0") ? "1" : "0";

                if (string.Equals(response, "1"))
                {
                    _errorLog.LogSmsSuccess(_smsSuccessDir, "product id", accountNo, toNumber, smsContent, "Success");
                }
                else
                {
                    _errorLog.LogSmsFailed(_smsFailDir, "product id", accountNo, toNumber, smsContent, "Failed");
                }
            }
            catch (Exception e)
            {
                _errorLog.LogError(e.Message);
            }

        }

        private void BanglalinkApi(string smsContent, string toNumber, string accountNo, out string response)
        {
            response = string.Empty;

            try
            {
                string url = _blProviderApi + "?msisdn=" + toNumber + "&message=" + smsContent + "&userID=" + _blUserName + "&passwd=" + _blPass + "&sender=" + _blMasking;
                using WebClient wc = new WebClient();
                string xml = wc.DownloadString(url);
                string[] separator = { "and" };
                string success = xml.Split(separator, StringSplitOptions.RemoveEmptyEntries)[0];
                response = success.Contains('1') ? "1" : "0";

                if (string.Equals(response, "1"))
                {
                    _errorLog.LogSmsSuccess(_smsSuccessDir, "product id", accountNo, toNumber, smsContent, "Success");
                }
                else
                {
                    _errorLog.LogSmsFailed(_smsFailDir, "product id", accountNo, toNumber, smsContent, "Failed");
                }

            }
            catch (Exception e)
            {
                _errorLog.LogError(e.Message);
            }
        }

        private void DefaultApi(string smsContent, string toNumber, string accountNo, out string error, out string response)
        {
            response = string.Empty;
            error = string.Empty;

            try
            {
                //Default-Robi
                if (string.Equals(_defaultProviderId, "18"))
                {
                    RobiApi(smsContent, toNumber, accountNo, out error, out response);
                }
                //Default-BL
                else if (string.Equals(_defaultProviderId, "19"))
                {
                    BanglalinkApi(smsContent, toNumber, accountNo, out response);
                }
                //Default-GP
                else if (string.Equals(_defaultProviderId, "17"))
                {
                    try
                    {
                        string url = _gpProviderApi + "?username=" + _gpUserName + "&password=" + _gpPass + "&apicode=1&msisdn=" + toNumber + "&countrycode=880&cli= " + _gpMasking + "&messagetype=1&message=" + smsContent + "&messageid=0";
                        using WebClient wc = new WebClient();
                        string xml = wc.DownloadString(url);
                        response = xml;
                        _errorLog.LogSmsSuccess(_smsSuccessDir, "product id", accountNo, toNumber, smsContent, "Success");
                    }
                    catch (Exception e)
                    {
                        _errorLog.LogError(e.Message);
                    }
                }
            }
            catch (Exception ex)
            {
                _errorLog.LogError(ex.Message);
            }
        }

        public async Task UflSmsSendApiAsync(string smsContent, string toNumber, string accountNo)
        {
            try
            {
                if (string.Equals(_apiMood, "UAT"))
                {
                    toNumber = _toNumber;
                }

                if (!string.IsNullOrWhiteSpace(toNumber))
                {
                    if (toNumber.Length > 10)
                    {
                        string parameters = "?MobileNo=" + toNumber + "&SmsBody=" + smsContent + "&RequestId=" + accountNo;
                        var uri = new Uri(_uflApiBaseUrl + parameters);

                        HttpClient client = _clientFactory.CreateClient("BankClient");
                        client.DefaultRequestHeaders.Accept.Clear();
                        client.DefaultRequestHeaders.Add("APIKey", _uflApiKey);
                        HttpResponseMessage result = await client.PostAsync(uri, null);

                        string response = result.Content.ReadAsStringAsync().Result;

                        if (response.Contains("1"))
                        {
                            _errorLog.LogSmsSuccess(_smsSuccessDir, "product id", accountNo, toNumber, smsContent, "Success = " + response);
                        }
                        else
                        {
                            _errorLog.LogSmsFailed(_smsFailDir, "product id", accountNo, toNumber, smsContent, "Failed = " + response);
                        }
                    }
                    else
                    {
                        _errorLog.LogSmsFailed(_smsFailDir, "product id", accountNo, toNumber, smsContent, "Phone number required length is minimum 11.");
                    }
                }
                else
                {
                    _errorLog.LogSmsFailed(_smsFailDir, "product id", accountNo, toNumber, smsContent, "Phone number can not be null or empty.");
                }
            }
            catch (Exception e)
            {
                _errorLog.LogSmsFailed(_smsFailDir, "product id", accountNo, toNumber, smsContent, "Failed, = ex = " + e.Message);
                _errorLog.LogError(e.Message);
            }
        }

        public void SendSmsAsync(string smsContent, string toNumber, string smsOperator, string accountNo, out int sendRes, out string smsReasonForFail)
        {
            try
            {
                if (string.Equals(_sslMood, "TRUE"))
                {
                    var res = SslApiHttpClientAsync(smsContent, toNumber, accountNo).Result;
                    sendRes = res.Item1;
                    smsReasonForFail = res.Item2;


                    //SslApiWebClient(smsContent, toNumber, accountNo);
                }
                else
                {
                    string error = string.Empty;
                    string response = string.Empty;
                    //test
                    sendRes = 1;
                    smsReasonForFail = "";

                    switch (smsOperator)
                    {
                        case "Robi":
                            {
                                RobiApi(smsContent, toNumber, accountNo, out error, out response);
                                break;
                            }

                        case "Banglalink":
                            {
                                BanglalinkApi(smsContent, toNumber, accountNo, out response);
                                break;
                            }

                        default:
                            {
                                DefaultApi(smsContent, toNumber, accountNo, out error, out response);
                                break;
                            }
                    }
                }
            }
            catch (Exception e)
            {
                _errorLog.LogError(e.Message);
                sendRes = 0;
                smsReasonForFail = e.Message;
            }
        }

        private async Task<Tuple<int, string>> InfobipHttpClientAsync(string smsContent, string toNumber, string accountNo)
        {
            try
            {
                if (string.Equals(_apiMood, "UAT"))
                {
                    toNumber = _toNumber;
                }

                if (!string.IsNullOrWhiteSpace(toNumber))
                {
                    List<Destination> destinations = new List<Destination>()
                    {
                        new Destination { To = toNumber}
                    };

                    List<SmsMessage> smsMessages = new List<SmsMessage>()
                    {
                         new SmsMessage {From = "key", Text = smsContent, Destinations = destinations}
                    };

                    InfobipSmsRequest smsRequest = new InfobipSmsRequest()
                    {
                        Messages = smsMessages
                    };

                    HttpContent httpContent = new StringContent(JsonConvert.SerializeObject(smsRequest), Encoding.UTF8);
                    httpContent.Headers.ContentType = new MediaTypeHeaderValue("application/json");

                    string key = "gyg6ej";
                    string authorizationKey = "authorization key";

                    string uriKey = $@"https://{key}.api.infobip.com/sms/2/text/advanced";



                    string parameters = "?MobileNo=" + toNumber + "&SmsBody=" + smsContent + "&RequestId=" + accountNo;

                    var uri = new Uri(uriKey);

                    HttpClient client = _clientFactory.CreateClient("BankClient");

                    client.Timeout = new TimeSpan(-1);

                    client.DefaultRequestHeaders.Accept.Clear();

                    client.DefaultRequestHeaders.Add("Authorization", authorizationKey);

                    HttpResponseMessage result = await client.PostAsync(uri, httpContent);

                    string response = await result.Content.ReadAsStringAsync();

                    if (result.IsSuccessStatusCode)
                    {
                        InfobipSuccessResponse infobipSuccess = JsonConvert.DeserializeObject<InfobipSuccessResponse>(response);




                    }
                    else
                    {
                        InfobipErrorResponse infobipError = JsonConvert.DeserializeObject<InfobipErrorResponse>(response);






                    }

                    return new Tuple<int, string>(1, "");
                }
                else
                {
                    return new Tuple<int, string>(0, "Invalid Phone Number.");
                }
            }
            catch (Exception e)
            {
                _errorLog.LogError(e.Message);
                return new Tuple<int, string>(0, e.Message);
            }
        }

        public void SendSmsOnAppShutDown()
        {
            try
            {
                switch (_bankName.ToUpper())
                {
                    case "LBFL"://lanka bangla
                        //_smsRepo.SendSmsAsync(smsContent, toNumber, smsOperator, accountNo, out smsRespFlag, out smsReasonForFail);
                        break;
                    case "MMBL"://modhu moti
                        SslApiHttpClientAsync("Notification Alert Service STOP. PLEASE START IT AGAIN.", _toNumber, "").Wait();
                        break;
                    case "UFL"://united finance
                        UflSmsSendApiAsync("Notification Alert Service STOP. PLEASE START IT AGAIN.", _toNumber, "").Wait();
                        break;
                    case "UBL"://uttara bank
                        SslApiHttpClientAsync("Notification Alert Service STOP. PLEASE START IT AGAIN.", _toNumber, "").Wait();
                        break;
                    case "MBL"://Meghna Bank
                        SslApiHttpClientAsync("Notification Alert Service STOP. PLEASE START IT AGAIN.", _toNumber, "").Wait();
                        break;
                    case "FSIBL"://First Security
                        SslApiHttpClientAsync("Notification Alert Service STOP. PLEASE START IT AGAIN.", _toNumber, "").Wait();
                        break;
                    case "SEBL"://South East
                        SslApiHttpClientAsync("Notification Alert Service STOP. PLEASE START IT AGAIN.", _toNumber, "").Wait();
                        break;
                    case "DBL"://Dhaka Bank
                        SslApiHttpClientAsync("Notification Alert Service STOP. PLEASE START IT AGAIN.", _toNumber, "").Wait();
                        break;
                    default:
                        break;
                }

                //var res = SslApiHttpClientAsync("Notification Alert Service STOP. PLEASE START IT AGAIN.", _toNumber, "").Result;
                
            }
            catch (Exception e)
            {
                _errorLog.LogError(e.Message);
            }
        }

    }
}
