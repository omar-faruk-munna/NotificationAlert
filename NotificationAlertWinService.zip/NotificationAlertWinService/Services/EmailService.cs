﻿using HtmlAgilityPack;
using Microsoft.Extensions.Configuration;
using NotificationAlertWinService.Repositories;
using Oracle.ManagedDataAccess.Types;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Threading.Tasks;

namespace NotificationAlertWinService.Services
{
    public class EmailService : IEmailRepository
    {
        #region Fields
        private readonly IConfiguration _configuration;
        private readonly ILogRepository _errorLog;
        //private const string _emailHeadFormat = "Sent Time\tProduct Id\tAccount Number\tEmail\tEmail Text\tStatus";
        private readonly string _apiMood;
        private readonly string _toEmail;
        private readonly string _smtpHost;
        private readonly int _smtpPort;
        private readonly string _smtpUserName;
        private readonly string _smtpPass;
        private readonly string _smtpMasking;
        private readonly bool _smtpUseDefaultCredentials;
        private readonly bool _smtpEnableSsl;
        private readonly string _emailSuccessDir;
        private readonly string _emailFailDir;

        #endregion

        public EmailService(IConfiguration configuration, ILogRepository errorLog)
        {
            _configuration = configuration;
            _errorLog = errorLog;
            _apiMood = _configuration.GetSection("API_ExecutionMode").GetSection("MODE").Value.ToUpper();
            _toEmail = _configuration.GetSection("API_ExecutionMode").GetSection("EMAIL").Value;
            _smtpHost = _configuration.GetSection("SMTP_Credentials").GetSection("Server").Value;
            _smtpPort = Convert.ToInt32(_configuration.GetSection("SMTP_Credentials").GetSection("Port").Value);
            _smtpUserName = _configuration.GetSection("SMTP_Credentials").GetSection("Email").Value;
            _smtpMasking = _configuration.GetSection("SMTP_Credentials").GetSection("Masking").Value;
            _smtpPass = _configuration.GetSection("SMTP_Credentials").GetSection("Password").Value;
            _smtpUseDefaultCredentials = Convert.ToBoolean(_configuration.GetSection("SMTP_Credentials").GetSection("UseDefaultCredentials").Value);
            _smtpEnableSsl = Convert.ToBoolean(_configuration.GetSection("SMTP_Credentials").GetSection("EnableSsl").Value);
            _emailSuccessDir = _configuration.GetSection("EmailSuccessDir").Value;
            _emailFailDir = _configuration.GetSection("EmailFailDir").Value;


        }

        public async Task SendEmailAsync(OracleClob clob, string toEmail, string accountNo)
        {
            try
            {
                if (string.Equals(_apiMood, "UAT"))
                {
                    toEmail = _toEmail;
                }

                string line1 = null;
                string clobString = clob.ToString();
                HtmlDocument body = new HtmlDocument();
                body.LoadHtml(clobString);
                HtmlNode bodyNode = body.DocumentNode.SelectSingleNode("//body");
                List<HtmlNode> nodesToRemove = new List<HtmlNode>();

                if (bodyNode != null)
                {
                    nodesToRemove.AddRange(bodyNode.ChildNodes.Where(des => des.Name != "table"));
                }

                foreach (HtmlNode node in nodesToRemove) node.Remove();

                if (bodyNode != null)
                {
                    string s = bodyNode.InnerText;
                    s = s.Trim();
                    line1 = s.Split(new[] { '\r', '\n' }).FirstOrDefault();
                }

                try
                {
                    using MailMessage mailMessage = new MailMessage();
                    using SmtpClient client = new SmtpClient(_smtpHost, _smtpPort)
                    {
                        EnableSsl = true,
                        Credentials = new NetworkCredential(_smtpUserName, _smtpPass)
                    };
                    client.EnableSsl = _smtpEnableSsl;
                    client.DeliveryMethod = SmtpDeliveryMethod.Network;
                    mailMessage.To.Add(toEmail);
                    mailMessage.Subject = line1;
                    mailMessage.Body = clobString;
                    mailMessage.IsBodyHtml = true;
                    client.Send(mailMessage);
                    _errorLog.LogEmailSuccess(_emailSuccessDir, "product id", accountNo, toEmail, clobString, "Success");
                }
                catch (Exception)
                {
                    _errorLog.LogEmailFailed(_emailFailDir, "product id", accountNo, toEmail, clobString, "Failed");
                }
            }
            catch (Exception e)
            {
                _errorLog.LogError(e.Message);
            }
        }

        public void SendEmailAsync(string clob, string toEmail, string accountNo, string emailSubject, string content, out int sendRes, out string emaiReasonForFail)
        {
            sendRes = 0;
            emaiReasonForFail = "";

            try
            {
                if (string.Equals(_apiMood, "UAT"))
                {
                    toEmail = _toEmail;
                }

                string line1 = null;
                string clobString = clob.ToString();
                HtmlDocument body = new HtmlDocument();
                body.LoadHtml(clobString);
                HtmlNode bodyNode = body.DocumentNode.SelectSingleNode("//body");
                List<HtmlNode> nodesToRemove = new List<HtmlNode>();

                if (bodyNode != null)
                {
                    nodesToRemove.AddRange(bodyNode.ChildNodes.Where(des => des.Name != "table"));
                }

                foreach (HtmlNode node in nodesToRemove)
                {
                    node.Remove();
                }

                if (bodyNode != null)
                {
                    string s = bodyNode.InnerText;
                    s = s.Trim();
                    line1 = s.Split(new[] { '\r', '\n' }).FirstOrDefault();
                }

                try
                {
                    using MailMessage mailMessage = new MailMessage();
                    using SmtpClient client = new SmtpClient(_smtpHost, _smtpPort);

                    try
                    {
                        client.UseDefaultCredentials = _smtpUseDefaultCredentials;
                        client.EnableSsl = _smtpEnableSsl;
                        client.Credentials = new NetworkCredential(_smtpUserName, _smtpPass);
                        client.DeliveryMethod = SmtpDeliveryMethod.Network;
                        mailMessage.To.Add(toEmail);
                        mailMessage.Subject = emailSubject;
                        mailMessage.Body = clobString;
                        mailMessage.IsBodyHtml = true;
                        mailMessage.From = new MailAddress(_smtpUserName, _smtpMasking);
                        client.Send(mailMessage);
                        sendRes = 1;
                        _errorLog.LogEmailSuccess(_emailSuccessDir, "product id", accountNo, toEmail, content, "Success");
                    }
                    catch (Exception e)
                    {
                        emaiReasonForFail = e.Message;
                        _errorLog.LogEmailFailed(_emailFailDir, "product id", accountNo, toEmail, content, "Failed");
                    }
                }
                catch (Exception e)
                {
                    emaiReasonForFail = e.Message;
                    _errorLog.LogError(e.Message);
                }
            }
            catch (Exception e)
            {
                _errorLog.LogError(e.Message);
            }
        }

        public void ServiceStopSendEmailAsync()
        {
            try
            {
                string subject = "Notification Alert Service";
                string content = "Notification Alert Service STOP. PLEASE START IT AGAIN.";

                try
                {
                    using MailMessage mailMessage = new MailMessage();
                    using SmtpClient client = new SmtpClient(_smtpHost, _smtpPort);

                    try
                    {
                        client.UseDefaultCredentials = _smtpUseDefaultCredentials;
                        client.EnableSsl = _smtpEnableSsl;
                        client.Credentials = new NetworkCredential(_smtpUserName, _smtpPass);
                        client.DeliveryMethod = SmtpDeliveryMethod.Network;
                        mailMessage.To.Add(_toEmail);
                        mailMessage.Subject = subject;
                        mailMessage.Body = content;
                        mailMessage.IsBodyHtml = false;
                        mailMessage.From = new MailAddress(_smtpUserName, _smtpMasking);
                        client.Send(mailMessage);

                        _errorLog.LogError(content);
                    }
                    catch (Exception e)
                    {
                        _errorLog.LogError("Service Stop Email Send Failed. ===== " + e.Message);
                    }
                }
                catch (Exception e)
                {
                    _errorLog.LogError("Service Stop ===== " + e.Message);
                }
            }
            catch (Exception e)
            {
                _errorLog.LogError("Service Stop ===== " + e.Message);
            }
        }

    }
}
