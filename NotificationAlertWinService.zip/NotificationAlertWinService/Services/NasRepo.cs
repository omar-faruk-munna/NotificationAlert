﻿using Dapper;
using Microsoft.Extensions.Configuration;
using NotificationAlertWinService.Helpers;
using NotificationAlertWinService.Repositories;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace NotificationAlertWinService.Services
{
    public class NasRepo : INasRepo
    {
        #region Fields
        private readonly IConfiguration _configuration;
        private readonly Connection _connection;
        private readonly ILogRepository _errorLog;
        private readonly IEmailRepository _emailRepo;
        private readonly ISmsRepository _smsRepo;
        private readonly string _bankName;
        private readonly int _numberOfTry;
        const string recordUpdateQuery = "ALERT_SERVICE.alert_svc_rec_u";
        const string pendingRecInsertQuery = "ALERT_SERVICE.alert_svc_pending_rec_i";
        const string pendingRecEmailUpdateQuery = "ALERT_SERVICE.alert_svc_pending_rec_email_u";
        const string pendingRecGetQuery1 = "ALERT_SERVICE.alert_svc_pending_rec_gk2";
        const string pendingRecGetQuery2 = "ALERT_SERVICE.alert_svc_pending_rec_gk3";
        const string pendingRecUpdateQuery = "ALERT_SERVICE.alert_svc_pending_rec_u";
        const string fncRecGetQuery = "ALERT_SERVICE.ALERT_SVC_msg_fnc_ga";

        #endregion

        public NasRepo(IConfiguration configuration, ILogRepository errorLog, IEmailRepository emailRepo, ISmsRepository smsRepo)
        {
            this._configuration = configuration;
            this._connection = new Connection();
            this._errorLog = errorLog;
            this._emailRepo = emailRepo;
            this._smsRepo = smsRepo;
            this._bankName = _configuration.GetSection("BankName").Value;
            this._numberOfTry = Convert.ToInt32(_configuration.GetSection("NumberOfTry").Value);
        }

        public async Task NasAsync1(string dbCon)
        {
            try
            {
                //ufl: 31-12-2030
                //ubl: 
                //mmbl: 26-4-2021
                //mbl: 
                //lbfl: 
                //dbl: 
                //sebl:
                //fsibl:

                if (DateTime.Now.Ticks > new DateTime(2030, 12, 30).Ticks)
                {
                    _errorLog.LogLicenseExpired("License Expired on 2030-12-30");
                    return;
                }

                OracleDynamicParameters dynamicParameters = new OracleDynamicParameters();
                dynamicParameters.Add("pname_value_list", 0, OracleDbType.Int32, ParameterDirection.Input);
                dynamicParameters.Add("pmsg_fnc_id", null, OracleDbType.NVarchar2, ParameterDirection.Input);
                dynamicParameters.Add("presult_set_cur", null, OracleDbType.RefCursor, ParameterDirection.Output);
                //const string query = "NOTIFICATION_ALERT_SERVICE.nas_alert_msg_fnc_ga";

                using IDbConnection con = _connection.GetConnection(dbCon);
                con.Open();

                try
                {
                    IEnumerable<dynamic> result = await con.QueryAsync<dynamic>(fncRecGetQuery, dynamicParameters, commandType: CommandType.StoredProcedure);

                    result = result.Cast<IDictionary<string, object>>();

                    var options = new ParallelOptions() { MaxDegreeOfParallelism = 3 };

                    Parallel.ForEach(result, options, async rows =>
                    {
                        if (!(rows is IDictionary<string, object> fields))
                        {
                            return;
                        }

                        int delay = Convert.ToInt32(fields["TIMER_SCAN_INTRV"]);
                        string processName = Convert.ToString(fields["PROCESS_NAME"]);
                        string frequency = Convert.ToString(fields["PROCESS_FREQ"]);
                        DateTime lastExecution = Convert.ToDateTime(Convert.ToString(fields["PROCESS_LAST_EXEC"]));
                        string emailSubject = Convert.ToString(fields["EMAIL_SUBJECT"]);

                        await SendAlertAsync(frequency, processName, lastExecution, delay, emailSubject, dbCon);

                    });
                }
                catch (Exception)
                {
                    _errorLog.LogError("Connection Exeption");
                }

                con.Close();
                con.Dispose();
            }
            catch (Exception e)
            {
                _errorLog.LogError(e.Message);
            }
        }

        public async Task NasAsync2(string dbCon)
        {
            try
            {
                //ufl: 31-12-2030
                //ubl: 
                //mmbl: 30-4-2021
                //mbl: 
                //lbfl: 
                //dbl: 
                //sebl:
                //fsibl:

                if (DateTime.Now.Ticks > new DateTime(2030, 12, 30).Ticks)
                {
                    _errorLog.LogLicenseExpired("License Expired on 2030-12-30");
                    return;
                }

                using IDbConnection con = _connection.GetConnection(dbCon);
                con.Open();

                try
                {
                    OracleDynamicParameters readParameters = new OracleDynamicParameters();
                    readParameters.Add("presult_cursor", null, OracleDbType.RefCursor, ParameterDirection.Output);

                    IEnumerable<dynamic> pendingResult = await con.QueryAsync(pendingRecGetQuery1, readParameters, commandType: CommandType.StoredProcedure);

                    foreach (var item in pendingResult)
                    {
                        if (item is IDictionary<string, object> fields)
                        {
                            int recId = Convert.ToInt32(fields["REC_ID"]);
                            int smsRespFlag = Convert.ToInt32(fields["SMS_RESP_FLAG"]);
                            int emailRespFlag = Convert.ToInt32(fields["EMAIL_RESP_FLAG"]);
                            int smsTryNo = Convert.ToInt32(fields["SMS_TRY_NO"]);
                            string smsReasonForFailGet = Convert.ToString(fields["SMS_REASON_FOR_FAIL"]);
                            int emailTryNo = Convert.ToInt32(fields["EMAIL_TRY_NO"]);
                            string emailReasonForFailGet = Convert.ToString(fields["EMAIL_REASON_FOR_FAIL"]);
                            string accountNo = Convert.ToString(fields["ACCOUNT_NO"]);
                            string productId = Convert.ToString(fields["PRODUCT_ID"]);
                            string smsContent = Convert.ToString(fields["SMS_TEXT"]);
                            string toNumber = Convert.ToString(fields["MOBILE_NUMBER"]);
                            string smsOperator = Convert.ToString(fields["MOBILE_OPERATOR"]);
                            string emailBlob = Convert.ToString(fields["EMAIL_BODY"]);
                            string toEmail = Convert.ToString(fields["EMAIL_ID"]);
                            //OracleClob emailBlob = (OracleClob)fields["EMAIL_BODY"];

                            string smsReasonForFail = "";
                            string emailReasonForFail = "";

                            OracleDynamicParameters updateParameters = new OracleDynamicParameters();
                            updateParameters.Add("prec_id", recId, OracleDbType.Int32, ParameterDirection.Input);

                            if (smsRespFlag == 0)
                            {
                                if (smsTryNo == 1)
                                {
                                    switch (_bankName.ToUpper())
                                    {
                                        case "LBFL"://lanka bangla
                                            _smsRepo.SendSmsAsync(smsContent, toNumber, smsOperator, accountNo, out smsRespFlag, out smsReasonForFail);
                                            break;
                                        case "MMBL"://modhu moti
                                            _smsRepo.SendSmsAsync(smsContent, toNumber, smsOperator, accountNo, out smsRespFlag, out smsReasonForFail);
                                            break;
                                        case "UFL"://united finance
                                            await _smsRepo.UflSmsSendApiAsync(smsContent, toNumber, accountNo);
                                            break;
                                        case "UBL"://uttara bank
                                            _smsRepo.SendSmsAsync(smsContent, toNumber, smsOperator, accountNo, out smsRespFlag, out smsReasonForFail);
                                            break;
                                        case "MBL"://Meghna Bank
                                            _smsRepo.SendSmsAsync(smsContent, toNumber, smsOperator, accountNo, out smsRespFlag, out smsReasonForFail);
                                            break;
                                        case "FSIBL"://First Security
                                            _smsRepo.SendSmsAsync(smsContent, toNumber, smsOperator, accountNo, out smsRespFlag, out smsReasonForFail);
                                            break;
                                        case "SEBL"://South East
                                            _smsRepo.SendSmsAsync(smsContent, toNumber, smsOperator, accountNo, out smsRespFlag, out smsReasonForFail);
                                            break;
                                        case "DBL"://Dhaka Bank
                                            _smsRepo.SendSmsAsync(smsContent, toNumber, smsOperator, accountNo, out smsRespFlag, out smsReasonForFail);
                                            break;
                                        default:
                                            break;
                                    }

                                    smsTryNo = 2;

                                    updateParameters.Add("psms_try_no", smsTryNo, OracleDbType.Int32, ParameterDirection.Input);

                                    if (smsRespFlag == 1)
                                    {
                                        updateParameters.Add("psms_resp_flag", smsRespFlag, OracleDbType.Int32, ParameterDirection.Input);
                                        updateParameters.Add("psms_reason_for_fail", smsReasonForFailGet, OracleDbType.Varchar2, ParameterDirection.Input);
                                    }
                                    else
                                    {
                                        updateParameters.Add("psms_resp_flag", smsRespFlag, OracleDbType.Int32, ParameterDirection.Input);
                                        updateParameters.Add("psms_reason_for_fail", smsReasonForFail, OracleDbType.Varchar2, ParameterDirection.Input);
                                    }
                                }
                            }
                            else
                            {
                                updateParameters.Add("psms_try_no", smsTryNo, OracleDbType.Int32, ParameterDirection.Input);
                                updateParameters.Add("psms_resp_flag", smsRespFlag, OracleDbType.Int32, ParameterDirection.Input);
                                updateParameters.Add("psms_reason_for_fail", smsReasonForFailGet, OracleDbType.Varchar2, ParameterDirection.Input);
                            }

                            if (emailRespFlag == 0)
                            {
                                if (emailTryNo == 1)
                                {
                                    string emailSubject = _bankName + " Email Alert";

                                    switch (_bankName.ToUpper())
                                    {
                                        case "LBFL"://lanka bangla
                                            _emailRepo.SendEmailAsync(emailBlob, toEmail, accountNo, emailSubject, smsContent, out emailRespFlag, out emailReasonForFail);
                                            break;
                                        case "MMBL"://modhu moti
                                            _emailRepo.SendEmailAsync(emailBlob, toEmail, accountNo, emailSubject, smsContent, out emailRespFlag, out emailReasonForFail);
                                            break;
                                        case "UFL"://united finance
                                            _emailRepo.SendEmailAsync(emailBlob, toEmail, accountNo, emailSubject, smsContent, out emailRespFlag, out emailReasonForFail);
                                            break;
                                        case "UBL"://uttara bank
                                            _emailRepo.SendEmailAsync(emailBlob, toEmail, accountNo, emailSubject, smsContent, out emailRespFlag, out emailReasonForFail);
                                            break;
                                        case "MBL"://Meghna Bank
                                            _emailRepo.SendEmailAsync(emailBlob, toEmail, accountNo, emailSubject, smsContent, out emailRespFlag, out emailReasonForFail);
                                            break;
                                        case "FSIBL"://First Security
                                            _emailRepo.SendEmailAsync(emailBlob, toEmail, accountNo, emailSubject, smsContent, out emailRespFlag, out emailReasonForFail);
                                            break;
                                        case "SEBL"://South East
                                            _emailRepo.SendEmailAsync(emailBlob, toEmail, accountNo, emailSubject, smsContent, out emailRespFlag, out emailReasonForFail);
                                            break;
                                        case "DBL"://Dhaka Bank
                                            _emailRepo.SendEmailAsync(emailBlob, toEmail, accountNo, emailSubject, smsContent, out emailRespFlag, out emailReasonForFail);
                                            break;
                                        default:
                                            break;
                                    }

                                    emailTryNo = 2;

                                    updateParameters.Add("pemail_try_no", emailTryNo, OracleDbType.Int32, ParameterDirection.Input);

                                    if (emailRespFlag == 1)
                                    {
                                        updateParameters.Add("pemail_resp_flag", emailRespFlag, OracleDbType.Int32, ParameterDirection.Input);
                                        updateParameters.Add("pemail_reason_for_fail", emailReasonForFailGet, OracleDbType.Varchar2, ParameterDirection.Input);
                                    }
                                    else
                                    {
                                        updateParameters.Add("pemail_resp_flag", emailRespFlag, OracleDbType.Int32, ParameterDirection.Input);
                                        updateParameters.Add("pemail_reason_for_fail", emailReasonForFail, OracleDbType.Varchar2, ParameterDirection.Input);
                                    }
                                }

                            }
                            else
                            {
                                updateParameters.Add("pemail_try_no", emailTryNo, OracleDbType.Int32, ParameterDirection.Input);
                                updateParameters.Add("pemail_resp_flag", emailRespFlag, OracleDbType.Int32, ParameterDirection.Input);
                                updateParameters.Add("pemail_reason_for_fail", emailReasonForFailGet, OracleDbType.Varchar2, ParameterDirection.Input);
                            }

                            con.QueryAsync(pendingRecUpdateQuery, updateParameters, commandType: CommandType.StoredProcedure).Wait();
                        }
                    }
                }
                catch (Exception e)
                {
                    _errorLog.LogError(e.Message);
                }

                con.Close();
                con.Dispose();
            }
            catch (Exception e)
            {
                _errorLog.LogError(e.Message);
            }
        }

        public async Task NasAsync3(string dbCon)
        {
            try
            {
                //ufl: 31-12-2030
                //ubl: 
                //mmbl: 30-4-2021
                //mbl: 
                //lbfl: 
                //dbl: 
                //sebl:
                //fsibl:

                if (DateTime.Now.Ticks > new DateTime(2030, 12, 30).Ticks)
                {
                    _errorLog.LogLicenseExpired("License Expired on 2030-12-30");
                    return;
                }

                using IDbConnection con = _connection.GetConnection(dbCon);
                con.Open();

                try
                {
                    OracleDynamicParameters readParameters = new OracleDynamicParameters();
                    readParameters.Add("presult_cursor", null, OracleDbType.RefCursor, ParameterDirection.Output);

                    IEnumerable<dynamic> pendingResult = await con.QueryAsync(pendingRecGetQuery2, readParameters, commandType: CommandType.StoredProcedure);

                    foreach (var item in pendingResult)
                    {
                        if (item is IDictionary<string, object> fields)
                        {
                            int recId = Convert.ToInt32(fields["REC_ID"]);
                            int smsRespFlag = Convert.ToInt32(fields["SMS_RESP_FLAG"]);
                            int emailRespFlag = Convert.ToInt32(fields["EMAIL_RESP_FLAG"]);
                            int smsTryNo = Convert.ToInt32(fields["SMS_TRY_NO"]);
                            string smsReasonForFailGet = Convert.ToString(fields["SMS_REASON_FOR_FAIL"]);
                            int emailTryNo = Convert.ToInt32(fields["EMAIL_TRY_NO"]);
                            string emailReasonForFailGet = Convert.ToString(fields["EMAIL_REASON_FOR_FAIL"]);
                            string accountNo = Convert.ToString(fields["ACCOUNT_NO"]);
                            string productId = Convert.ToString(fields["PRODUCT_ID"]);
                            string smsContent = Convert.ToString(fields["SMS_TEXT"]);
                            string toNumber = Convert.ToString(fields["MOBILE_NUMBER"]);
                            string smsOperator = Convert.ToString(fields["MOBILE_OPERATOR"]);
                            string emailBlob = Convert.ToString(fields["EMAIL_BODY"]);
                            string toEmail = Convert.ToString(fields["EMAIL_ID"]);
                            //OracleClob emailBlob = (OracleClob)fields["EMAIL_BODY"];

                            string smsReasonForFail = "";
                            string emailReasonForFail = "";

                            OracleDynamicParameters updateParameters = new OracleDynamicParameters();
                            updateParameters.Add("prec_id", recId, OracleDbType.Int32, ParameterDirection.Input);

                            if (smsRespFlag == 0)
                            {
                                if (smsTryNo == 2)
                                {
                                    switch (_bankName.ToUpper())
                                    {
                                        case "LBFL"://lanka bangla
                                            _smsRepo.SendSmsAsync(smsContent, toNumber, smsOperator, accountNo, out smsRespFlag, out smsReasonForFail);
                                            break;
                                        case "MMBL"://modhu moti
                                            _smsRepo.SendSmsAsync(smsContent, toNumber, smsOperator, accountNo, out smsRespFlag, out smsReasonForFail);
                                            break;
                                        case "UFL"://united finance
                                            await _smsRepo.UflSmsSendApiAsync(smsContent, toNumber, accountNo);
                                            break;
                                        case "UBL"://uttara bank
                                            _smsRepo.SendSmsAsync(smsContent, toNumber, smsOperator, accountNo, out smsRespFlag, out smsReasonForFail);
                                            break;
                                        case "MBL"://Meghna Bank
                                            _smsRepo.SendSmsAsync(smsContent, toNumber, smsOperator, accountNo, out smsRespFlag, out smsReasonForFail);
                                            break;
                                        case "FSIBL"://First Security
                                            _smsRepo.SendSmsAsync(smsContent, toNumber, smsOperator, accountNo, out smsRespFlag, out smsReasonForFail);
                                            break;
                                        case "SEBL"://South East
                                            _smsRepo.SendSmsAsync(smsContent, toNumber, smsOperator, accountNo, out smsRespFlag, out smsReasonForFail);
                                            break;
                                        case "DBL"://Dhaka Bank
                                            _smsRepo.SendSmsAsync(smsContent, toNumber, smsOperator, accountNo, out smsRespFlag, out smsReasonForFail);
                                            break;
                                        default:
                                            break;
                                    }

                                    smsTryNo = 3;

                                    updateParameters.Add("psms_try_no", smsTryNo, OracleDbType.Int32, ParameterDirection.Input);

                                    if (smsRespFlag == 1)
                                    {
                                        updateParameters.Add("psms_resp_flag", smsRespFlag, OracleDbType.Int32, ParameterDirection.Input);
                                        updateParameters.Add("psms_reason_for_fail", smsReasonForFailGet, OracleDbType.Varchar2, ParameterDirection.Input);
                                    }
                                    else
                                    {
                                        updateParameters.Add("psms_resp_flag", smsRespFlag, OracleDbType.Int32, ParameterDirection.Input);
                                        updateParameters.Add("psms_reason_for_fail", smsReasonForFail, OracleDbType.Varchar2, ParameterDirection.Input);
                                    }
                                }
                            }
                            else
                            {
                                updateParameters.Add("psms_try_no", smsTryNo, OracleDbType.Int32, ParameterDirection.Input);
                                updateParameters.Add("psms_resp_flag", smsRespFlag, OracleDbType.Int32, ParameterDirection.Input);
                                updateParameters.Add("psms_reason_for_fail", smsReasonForFailGet, OracleDbType.Varchar2, ParameterDirection.Input);
                            }

                            if (emailRespFlag == 0)
                            {
                                if (emailTryNo == 2)
                                {
                                    string emailSubject = _bankName + " Email Alert";

                                    switch (_bankName.ToUpper())
                                    {
                                        case "LBFL"://lanka bangla
                                            _emailRepo.SendEmailAsync(emailBlob, toEmail, accountNo, emailSubject, smsContent, out emailRespFlag, out emailReasonForFail);
                                            break;
                                        case "MMBL"://modhu moti
                                            _emailRepo.SendEmailAsync(emailBlob, toEmail, accountNo, emailSubject, smsContent, out emailRespFlag, out emailReasonForFail);
                                            break;
                                        case "UFL"://united finance
                                            _emailRepo.SendEmailAsync(emailBlob, toEmail, accountNo, emailSubject, smsContent, out emailRespFlag, out emailReasonForFail);
                                            break;
                                        case "UBL"://uttara bank
                                            _emailRepo.SendEmailAsync(emailBlob, toEmail, accountNo, emailSubject, smsContent, out emailRespFlag, out emailReasonForFail);
                                            break;
                                        case "MBL"://Meghna Bank
                                            _emailRepo.SendEmailAsync(emailBlob, toEmail, accountNo, emailSubject, smsContent, out emailRespFlag, out emailReasonForFail);
                                            break;
                                        case "FSIBL"://First Security
                                            _emailRepo.SendEmailAsync(emailBlob, toEmail, accountNo, emailSubject, smsContent, out emailRespFlag, out emailReasonForFail);
                                            break;
                                        case "SEBL"://South East
                                            _emailRepo.SendEmailAsync(emailBlob, toEmail, accountNo, emailSubject, smsContent, out emailRespFlag, out emailReasonForFail);
                                            break;
                                        case "DBL"://Dhaka Bank
                                            _emailRepo.SendEmailAsync(emailBlob, toEmail, accountNo, emailSubject, smsContent, out emailRespFlag, out emailReasonForFail);
                                            break;
                                        default:
                                            break;
                                    }

                                    emailTryNo = 3;

                                    updateParameters.Add("pemail_try_no", emailTryNo, OracleDbType.Int32, ParameterDirection.Input);

                                    if (emailRespFlag == 1)
                                    {
                                        updateParameters.Add("pemail_resp_flag", emailRespFlag, OracleDbType.Int32, ParameterDirection.Input);
                                        updateParameters.Add("pemail_reason_for_fail", emailReasonForFailGet, OracleDbType.Varchar2, ParameterDirection.Input);
                                    }
                                    else
                                    {
                                        updateParameters.Add("pemail_resp_flag", emailRespFlag, OracleDbType.Int32, ParameterDirection.Input);
                                        updateParameters.Add("pemail_reason_for_fail", emailReasonForFail, OracleDbType.Varchar2, ParameterDirection.Input);
                                    }
                                }

                            }
                            else
                            {
                                updateParameters.Add("pemail_try_no", emailTryNo, OracleDbType.Int32, ParameterDirection.Input);
                                updateParameters.Add("pemail_resp_flag", emailRespFlag, OracleDbType.Int32, ParameterDirection.Input);
                                updateParameters.Add("pemail_reason_for_fail", emailReasonForFailGet, OracleDbType.Varchar2, ParameterDirection.Input);
                            }

                            con.QueryAsync(pendingRecUpdateQuery, updateParameters, commandType: CommandType.StoredProcedure).Wait();
                        }
                    }
                }
                catch (Exception e)
                {
                    _errorLog.LogError(e.Message);
                }

                con.Close();
                con.Dispose();
            }
            catch (Exception e)
            {
                _errorLog.LogError(e.Message);
            }
        }

        public async Task SendAlertAsync(string frequency, string processName, DateTime lastExecution, int delay, string emailSubject, string dbCon)
        {
            try
            {
                DateTime today = DateTime.Today;
                TimeSpan sinceLastExec = today.Subtract(lastExecution);
                IEnumerable<dynamic> result = null;
                OracleDynamicParameters dynamicParameters = new OracleDynamicParameters();
                dynamicParameters.Add("pauth_status_id", "A", OracleDbType.NVarchar2, ParameterDirection.Input);
                dynamicParameters.Add("presult_set_cur", null, OracleDbType.RefCursor, ParameterDirection.Output);

                using IDbConnection con = _connection.GetConnection(dbCon);
                con.Open();

                try
                {
                    if (frequency == "D" && sinceLastExec.Days >= 1) //Daily
                    {
                        try
                        {
                            result = await con.QueryAsync(processName, dynamicParameters, commandType: CommandType.StoredProcedure);
                        }
                        catch (Exception e)
                        {
                            _errorLog.LogError(e.Message);
                        }
                    }
                    else if (frequency == "M" && today.Day >= 1 && sinceLastExec.Days >= 1) //Monthly
                    {
                        try
                        {
                            result = await con.QueryAsync(processName, dynamicParameters, commandType: CommandType.StoredProcedure);
                        }
                        catch (Exception e)
                        {
                            _errorLog.LogError(e.Message);
                        }
                    }
                    else if (frequency == "T") //Timely
                    {
                        try
                        {
                            Task.Run(async () =>
                            {
                                result = await con.QueryAsync(processName, dynamicParameters, commandType: CommandType.StoredProcedure);
                            }).Wait(TimeSpan.FromMilliseconds(delay)); //delay value: 10000
                        }
                        catch (Exception e)
                        {
                            _errorLog.LogError(e.Message);
                        }
                    }

                    result = result?.Cast<IDictionary<string, object>>();

                    //--------------------

                    #region Start Try For First Time

                    if (result != null)
                    {
                        var options = new ParallelOptions() { MaxDegreeOfParallelism = 3 };

                        Parallel.ForEach(result, options, async rows =>
                        {
                            if (rows is IDictionary<string, object> fields)
                            {
                                int emailFlag = Convert.ToInt32(fields["EMAIL_SENT_FLAG"]);
                                int smsFlag = Convert.ToInt32(fields["SMS_SENT_FLAG"]);
                                string smsContent = Convert.ToString(fields["SMS_TEXT"]);
                                string accountNo = Convert.ToString(fields["ACCOUNT_NO"]);
                                string tableName = Convert.ToString(fields["TABLE_NAME"]);
                                string tableRowId = Convert.ToString(fields["TABLE_ROWID"]);
                                string emailBody = Convert.ToString(fields["EMAIL_BODY"]);
                                string toEmail = Convert.ToString(fields["EMAIL_ID"]);
                                //OracleClob emailBlob = (OracleClob)fields["EMAIL_BODY"];
                                string toNumber = Convert.ToString(fields["MOBILE_NUMBER"]);
                                string smsOperator = Convert.ToString(fields["MOBILE_OPERATOR"]);
                                int emailRespFlag = 0;
                                int smsRespFlag = 0;
                                string smsReasonForFail = "";
                                string emailReasonForFail = "";
                                string pendingTableRowId = "";

                                #region First Time Try

                                #region Sms

                                if (smsFlag == 1)
                                {
                                    switch (_bankName.ToUpper())
                                    {
                                        case "LBFL"://lanka bangla
                                            _smsRepo.SendSmsAsync(smsContent, toNumber, smsOperator, accountNo, out smsRespFlag, out smsReasonForFail);
                                            break;
                                        case "MMBL"://modhu moti
                                            _smsRepo.SendSmsAsync(smsContent, toNumber, smsOperator, accountNo, out smsRespFlag, out smsReasonForFail);
                                            break;
                                        case "UFL"://united finance
                                            await _smsRepo.UflSmsSendApiAsync(smsContent, toNumber, accountNo);
                                            break;
                                        case "UBL"://uttara bank
                                            _smsRepo.SendSmsAsync(smsContent, toNumber, smsOperator, accountNo, out smsRespFlag, out smsReasonForFail);
                                            break;
                                        case "MBL"://Meghna Bank
                                            _smsRepo.SendSmsAsync(smsContent, toNumber, smsOperator, accountNo, out smsRespFlag, out smsReasonForFail);
                                            break;
                                        case "FSIBL"://First Security
                                            _smsRepo.SendSmsAsync(smsContent, toNumber, smsOperator, accountNo, out smsRespFlag, out smsReasonForFail);
                                            break;
                                        case "SEBL"://South East
                                            _smsRepo.SendSmsAsync(smsContent, toNumber, smsOperator, accountNo, out smsRespFlag, out smsReasonForFail);
                                            break;
                                        case "DBL"://Dhaka Bank
                                            _smsRepo.SendSmsAsync(smsContent, toNumber, smsOperator, accountNo, out smsRespFlag, out smsReasonForFail);
                                            break;
                                        default:
                                            break;
                                    }

                                    if (smsRespFlag == 1)
                                    {
                                        //------- Sms Success, update main table
                                        OracleDynamicParameters parameters = new OracleDynamicParameters();
                                        parameters.Add("ptable_name", tableName, OracleDbType.Varchar2, ParameterDirection.Input);
                                        parameters.Add("ptable_rowid", tableRowId, OracleDbType.Varchar2, ParameterDirection.Input);

                                        con.QueryAsync(recordUpdateQuery, parameters, commandType: CommandType.StoredProcedure).Wait();
                                    }
                                    else
                                    {
                                        //------ Sms Failed, insert to pending table
                                        OracleDynamicParameters parameters = new OracleDynamicParameters();
                                        parameters.Add("pbranch_id", null, OracleDbType.Varchar2, ParameterDirection.Input);
                                        parameters.Add("pproduct_id", null, OracleDbType.Varchar2, ParameterDirection.Input);
                                        parameters.Add("paccount_no", accountNo, OracleDbType.Varchar2, ParameterDirection.Input);
                                        parameters.Add("psms_resp_flag", smsRespFlag, OracleDbType.Int32, ParameterDirection.Input);
                                        parameters.Add("psms_try_no", 1, OracleDbType.Int32, ParameterDirection.Input);
                                        parameters.Add("pmobile_operator", smsOperator, OracleDbType.Varchar2, ParameterDirection.Input);
                                        parameters.Add("pmobile_number", toNumber, OracleDbType.Varchar2, ParameterDirection.Input);
                                        parameters.Add("psms_text", smsContent, OracleDbType.Varchar2, ParameterDirection.Input);
                                        parameters.Add("pemail_resp_flag", emailRespFlag, OracleDbType.Int32, ParameterDirection.Input);
                                        parameters.Add("pemail_try_no", 0, OracleDbType.Int32, ParameterDirection.Input);
                                        parameters.Add("pemail_id", toEmail, OracleDbType.Varchar2, ParameterDirection.Input);
                                        parameters.Add("pemail_body", emailBody, OracleDbType.Clob, ParameterDirection.Input);
                                        parameters.Add("psms_reason_for_fail", smsReasonForFail, OracleDbType.Varchar2, ParameterDirection.Input);
                                        parameters.Add("pemail_reason_for_fail", emailReasonForFail, OracleDbType.Varchar2, ParameterDirection.Input);
                                        parameters.Add("prow_id", null, OracleDbType.Varchar2, ParameterDirection.Output);

                                        var rowId = await con.QueryAsync<string>(pendingRecInsertQuery, parameters, commandType: CommandType.StoredProcedure);

                                        pendingTableRowId = rowId.SingleOrDefault();
                                    }
                                }

                                #endregion

                                #region Email

                                if (emailFlag == 1)
                                {
                                    switch (_bankName.ToUpper())
                                    {
                                        case "LBFL"://lanka bangla
                                            _emailRepo.SendEmailAsync(emailBody, toEmail, accountNo, emailSubject, smsContent, out emailRespFlag, out emailReasonForFail);
                                            break;
                                        case "MMBL"://modhu moti
                                            _emailRepo.SendEmailAsync(emailBody, toEmail, accountNo, emailSubject, smsContent, out emailRespFlag, out emailReasonForFail);
                                            break;
                                        case "UFL"://united finance
                                            _emailRepo.SendEmailAsync(emailBody, toEmail, accountNo, emailSubject, smsContent, out emailRespFlag, out emailReasonForFail);
                                            break;
                                        case "UBL"://uttara bank
                                            _emailRepo.SendEmailAsync(emailBody, toEmail, accountNo, emailSubject, smsContent, out emailRespFlag, out emailReasonForFail);
                                            break;
                                        case "MBL"://Meghna Bank
                                            _emailRepo.SendEmailAsync(emailBody, toEmail, accountNo, emailSubject, smsContent, out emailRespFlag, out emailReasonForFail);
                                            break;
                                        case "FSIBL"://First Security
                                            _emailRepo.SendEmailAsync(emailBody, toEmail, accountNo, emailSubject, smsContent, out emailRespFlag, out emailReasonForFail);
                                            break;
                                        case "SEBL"://South East
                                            _emailRepo.SendEmailAsync(emailBody, toEmail, accountNo, emailSubject, smsContent, out emailRespFlag, out emailReasonForFail);
                                            break;
                                        case "DBL"://Dhaka Bank
                                            _emailRepo.SendEmailAsync(emailBody, toEmail, accountNo, emailSubject, smsContent, out emailRespFlag, out emailReasonForFail);
                                            break;
                                        default:
                                            break;
                                    }

                                    if (emailRespFlag == 1)
                                    {
                                        if (!string.IsNullOrWhiteSpace(pendingTableRowId))
                                        {
                                            //------- update main table
                                            OracleDynamicParameters parameters = new OracleDynamicParameters();
                                            parameters.Add("ptable_name", tableName, OracleDbType.Varchar2, ParameterDirection.Input);
                                            parameters.Add("ptable_rowid", tableRowId, OracleDbType.Varchar2, ParameterDirection.Input);

                                            con.QueryAsync(recordUpdateQuery, parameters, commandType: CommandType.StoredProcedure).Wait();

                                            //------- update pending table for email success
                                            OracleDynamicParameters updateParameters = new OracleDynamicParameters();
                                            updateParameters.Add("pemail_resp_flag", emailRespFlag, OracleDbType.Int32, ParameterDirection.Input);
                                            updateParameters.Add("pemail_try_no", 1, OracleDbType.Int32, ParameterDirection.Input);
                                            updateParameters.Add("pemail_reason_for_fail", emailReasonForFail, OracleDbType.Varchar2, ParameterDirection.Input);
                                            updateParameters.Add("prow_id", pendingTableRowId, OracleDbType.Varchar2, ParameterDirection.Input);

                                            con.QueryAsync(pendingRecEmailUpdateQuery, updateParameters, commandType: CommandType.StoredProcedure).Wait();
                                        }
                                    }
                                    else
                                    {
                                        //----- Email Send failed
                                        if (string.IsNullOrWhiteSpace(pendingTableRowId))
                                        {
                                            //----- sms send, so pendingTableRowId is empty, insert pending table
                                            OracleDynamicParameters parameters = new OracleDynamicParameters();
                                            parameters.Add("pbranch_id", null, OracleDbType.Varchar2, ParameterDirection.Input);
                                            parameters.Add("pproduct_id", null, OracleDbType.Varchar2, ParameterDirection.Input);
                                            parameters.Add("paccount_no", accountNo, OracleDbType.Varchar2, ParameterDirection.Input);
                                            parameters.Add("psms_resp_flag", smsRespFlag, OracleDbType.Int32, ParameterDirection.Input);
                                            parameters.Add("psms_try_no", 1, OracleDbType.Int32, ParameterDirection.Input);
                                            parameters.Add("pmobile_operator", smsOperator, OracleDbType.Varchar2, ParameterDirection.Input);
                                            parameters.Add("pmobile_number", toNumber, OracleDbType.Varchar2, ParameterDirection.Input);
                                            parameters.Add("psms_text", smsContent, OracleDbType.Varchar2, ParameterDirection.Input);
                                            parameters.Add("pemail_resp_flag", emailRespFlag, OracleDbType.Int32, ParameterDirection.Input);
                                            parameters.Add("pemail_try_no", 1, OracleDbType.Int32, ParameterDirection.Input);
                                            parameters.Add("pemail_id", toEmail, OracleDbType.Varchar2, ParameterDirection.Input);
                                            parameters.Add("pemail_body", emailBody, OracleDbType.Clob, ParameterDirection.Input);
                                            parameters.Add("psms_reason_for_fail", smsReasonForFail, OracleDbType.Varchar2, ParameterDirection.Input);
                                            parameters.Add("pemail_reason_for_fail", emailReasonForFail, OracleDbType.Varchar2, ParameterDirection.Input);
                                            parameters.Add("prow_id", null, OracleDbType.Varchar2, ParameterDirection.Output);

                                            con.QueryAsync(pendingRecInsertQuery, parameters, commandType: CommandType.StoredProcedure).Wait();
                                        }
                                        else
                                        {
                                            //------- update pending table for email
                                            OracleDynamicParameters updateParameters = new OracleDynamicParameters();
                                            updateParameters.Add("pemail_resp_flag", emailRespFlag, OracleDbType.Int32, ParameterDirection.Input);
                                            updateParameters.Add("pemail_try_no", 1, OracleDbType.Int32, ParameterDirection.Input);
                                            updateParameters.Add("pemail_reason_for_fail", emailReasonForFail, OracleDbType.Varchar2, ParameterDirection.Input);
                                            updateParameters.Add("prow_id", pendingTableRowId, OracleDbType.Varchar2, ParameterDirection.Input);

                                            con.QueryAsync(pendingRecEmailUpdateQuery, updateParameters, commandType: CommandType.StoredProcedure).Wait();
                                        }
                                    }
                                }

                                #endregion

                                #endregion
                            }
                        });
                    }

                    #endregion

                    //#region Start Try For Pending Table

                    //OracleDynamicParameters readParameters = new OracleDynamicParameters();
                    //readParameters.Add("presult_cursor", null, OracleDbType.RefCursor, ParameterDirection.Output);

                    //IEnumerable<dynamic> pendingResult = await con.QueryAsync(pendingRecGetQuery1, readParameters, commandType: CommandType.StoredProcedure);

                    //foreach (var item in pendingResult)
                    //{
                    //    if (item is IDictionary<string, object> fields)
                    //    {
                    //        int recId = Convert.ToInt32(fields["REC_ID"]);
                    //        int smsRespFlag = Convert.ToInt32(fields["SMS_RESP_FLAG"]);
                    //        int emailRespFlag = Convert.ToInt32(fields["EMAIL_RESP_FLAG"]);
                    //        int smsTryNo = Convert.ToInt32(fields["SMS_TRY_NO"]);
                    //        string smsReasonForFailGet = Convert.ToString(fields["SMS_REASON_FOR_FAIL"]);
                    //        int emailTryNo = Convert.ToInt32(fields["EMAIL_TRY_NO"]);
                    //        string emailReasonForFailGet = Convert.ToString(fields["EMAIL_REASON_FOR_FAIL"]);
                    //        string accountNo = Convert.ToString(fields["ACCOUNT_NO"]);
                    //        string productId = Convert.ToString(fields["PRODUCT_ID"]);
                    //        string smsContent = Convert.ToString(fields["SMS_TEXT"]);
                    //        string toNumber = Convert.ToString(fields["MOBILE_NUMBER"]);
                    //        string smsOperator = Convert.ToString(fields["MOBILE_OPERATOR"]);
                    //        string emailBlob = Convert.ToString(fields["EMAIL_BODY"]);
                    //        string toEmail = Convert.ToString(fields["EMAIL_ID"]);
                    //        //OracleClob emailBlob = (OracleClob)fields["EMAIL_BODY"];

                    //        string smsReasonForFail = "";
                    //        string emailReasonForFail = "";

                    //        OracleDynamicParameters updateParameters = new OracleDynamicParameters();
                    //        updateParameters.Add("prec_id", recId, OracleDbType.Int32, ParameterDirection.Input);

                    //        if (smsRespFlag == 0)
                    //        {
                    //            if (smsTryNo < _numberOfTry)
                    //            {
                    //                switch (_bankName.ToUpper())
                    //                {
                    //                    case "LBFL"://lanka bangla
                    //                        _smsRepo.SendSmsAsync(smsContent, toNumber, smsOperator, accountNo, out smsRespFlag, out smsReasonForFail);
                    //                        break;
                    //                    case "MMBL"://modhu moti
                    //                        _smsRepo.SendSmsAsync(smsContent, toNumber, smsOperator, accountNo, out smsRespFlag, out smsReasonForFail);
                    //                        break;
                    //                    case "UFL"://united finance
                    //                        await _smsRepo.UflSmsSendApiAsync(smsContent, toNumber, accountNo);
                    //                        break;
                    //                    case "UBL"://uttara bank
                    //                        _smsRepo.SendSmsAsync(smsContent, toNumber, smsOperator, accountNo, out smsRespFlag, out smsReasonForFail);
                    //                        break;
                    //                    case "MBL"://Meghna Bank
                    //                        _smsRepo.SendSmsAsync(smsContent, toNumber, smsOperator, accountNo, out smsRespFlag, out smsReasonForFail);
                    //                        break;
                    //                    case "FSIBL"://First Security
                    //                        _smsRepo.SendSmsAsync(smsContent, toNumber, smsOperator, accountNo, out smsRespFlag, out smsReasonForFail);
                    //                        break;
                    //                    case "SEBL"://South East
                    //                        _smsRepo.SendSmsAsync(smsContent, toNumber, smsOperator, accountNo, out smsRespFlag, out smsReasonForFail);
                    //                        break;
                    //                    case "DBL"://Dhaka Bank
                    //                        _smsRepo.SendSmsAsync(smsContent, toNumber, smsOperator, accountNo, out smsRespFlag, out smsReasonForFail);
                    //                        break;
                    //                    default:
                    //                        break;
                    //                }

                    //                smsTryNo++;

                    //                updateParameters.Add("psms_try_no", smsTryNo, OracleDbType.Int32, ParameterDirection.Input);

                    //                if (smsRespFlag == 1)
                    //                {
                    //                    updateParameters.Add("psms_resp_flag", smsRespFlag, OracleDbType.Int32, ParameterDirection.Input);
                    //                    updateParameters.Add("psms_reason_for_fail", smsReasonForFailGet, OracleDbType.Varchar2, ParameterDirection.Input);
                    //                }
                    //                else
                    //                {
                    //                    updateParameters.Add("psms_resp_flag", smsRespFlag, OracleDbType.Int32, ParameterDirection.Input);
                    //                    updateParameters.Add("psms_reason_for_fail", smsReasonForFail, OracleDbType.Varchar2, ParameterDirection.Input);
                    //                }
                    //            }
                    //        }
                    //        else
                    //        {
                    //            updateParameters.Add("psms_try_no", smsTryNo, OracleDbType.Int32, ParameterDirection.Input);
                    //            updateParameters.Add("psms_resp_flag", smsRespFlag, OracleDbType.Int32, ParameterDirection.Input);
                    //            updateParameters.Add("psms_reason_for_fail", smsReasonForFailGet, OracleDbType.Varchar2, ParameterDirection.Input);
                    //        }

                    //        if (emailRespFlag == 0)
                    //        {
                    //            if (emailTryNo < _numberOfTry)
                    //            {
                    //                switch (_bankName.ToUpper())
                    //                {
                    //                    case "LBFL"://lanka bangla
                    //                        _emailRepo.SendEmailAsync(emailBlob, toEmail, accountNo, emailSubject, smsContent, out emailRespFlag, out emailReasonForFail);
                    //                        break;
                    //                    case "MMBL"://modhu moti
                    //                        _emailRepo.SendEmailAsync(emailBlob, toEmail, accountNo, emailSubject, smsContent, out emailRespFlag, out emailReasonForFail);
                    //                        break;
                    //                    case "UFL"://united finance
                    //                        _emailRepo.SendEmailAsync(emailBlob, toEmail, accountNo, emailSubject, smsContent, out emailRespFlag, out emailReasonForFail);
                    //                        break;
                    //                    case "UBL"://uttara bank
                    //                        _emailRepo.SendEmailAsync(emailBlob, toEmail, accountNo, emailSubject, smsContent, out emailRespFlag, out emailReasonForFail);
                    //                        break;
                    //                    case "MBL"://Meghna Bank
                    //                        _emailRepo.SendEmailAsync(emailBlob, toEmail, accountNo, emailSubject, smsContent, out emailRespFlag, out emailReasonForFail);
                    //                        break;
                    //                    case "FSIBL"://First Security
                    //                        _emailRepo.SendEmailAsync(emailBlob, toEmail, accountNo, emailSubject, smsContent, out emailRespFlag, out emailReasonForFail);
                    //                        break;
                    //                    case "SEBL"://South East
                    //                        _emailRepo.SendEmailAsync(emailBlob, toEmail, accountNo, emailSubject, smsContent, out emailRespFlag, out emailReasonForFail);
                    //                        break;
                    //                    case "DBL"://Dhaka Bank
                    //                        _emailRepo.SendEmailAsync(emailBlob, toEmail, accountNo, emailSubject, smsContent, out emailRespFlag, out emailReasonForFail);
                    //                        break;
                    //                    default:
                    //                        break;
                    //                }

                    //                emailTryNo++;

                    //                updateParameters.Add("pemail_try_no", emailTryNo, OracleDbType.Int32, ParameterDirection.Input);

                    //                if (emailRespFlag == 1)
                    //                {
                    //                    updateParameters.Add("pemail_resp_flag", emailRespFlag, OracleDbType.Int32, ParameterDirection.Input);
                    //                    updateParameters.Add("pemail_reason_for_fail", emailReasonForFailGet, OracleDbType.Varchar2, ParameterDirection.Input);
                    //                }
                    //                else
                    //                {
                    //                    updateParameters.Add("pemail_resp_flag", emailRespFlag, OracleDbType.Int32, ParameterDirection.Input);
                    //                    updateParameters.Add("pemail_reason_for_fail", emailReasonForFail, OracleDbType.Varchar2, ParameterDirection.Input);
                    //                }
                    //            }

                    //        }
                    //        else
                    //        {
                    //            updateParameters.Add("pemail_try_no", emailTryNo, OracleDbType.Int32, ParameterDirection.Input);
                    //            updateParameters.Add("pemail_resp_flag", emailRespFlag, OracleDbType.Int32, ParameterDirection.Input);
                    //            updateParameters.Add("pemail_reason_for_fail", emailReasonForFailGet, OracleDbType.Varchar2, ParameterDirection.Input);
                    //        }

                    //        con.QueryAsync(pendingRecUpdateQuery, updateParameters, commandType: CommandType.StoredProcedure).Wait();
                    //    }
                    //}

                    //#endregion

                    //---------------------

                    //const string query = "NOTIFICATION_ALERT_SERVICE.set_last_execution";
                    const string query = "ALERT_SERVICE.set_last_execution";
                    OracleDynamicParameters parameters = new OracleDynamicParameters();
                    parameters.Add("pprocess_name", processName, OracleDbType.NVarchar2, ParameterDirection.Input);
                    await con.QueryAsync(query, parameters, commandType: CommandType.StoredProcedure);
                }
                catch (Exception e)
                {
                    _errorLog.LogError(e.Message);
                }

                con.Close();
                con.Dispose();
            }
            catch (Exception e)
            {
                _errorLog.LogError(e.Message);
            }
        }
    }
}
