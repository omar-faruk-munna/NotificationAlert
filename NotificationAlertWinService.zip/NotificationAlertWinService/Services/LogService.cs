﻿using log4net;
using log4net.Config;
using Microsoft.Extensions.Configuration;
using NotificationAlertWinService.Repositories;
using Serilog;
using System;
using System.IO;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace NotificationAlertWinService.Services
{
    public class LogService : ILogRepository
    {
        //private static readonly ILog log = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);
        private static readonly ILog smsSuccess = LogManager.GetLogger("SmsSuccess");
        private static readonly ILog smsFail = LogManager.GetLogger("SmsFail");
        private static readonly ILog emailSuccess = LogManager.GetLogger("EmailSuccess");
        private static readonly ILog emailFail = LogManager.GetLogger("EmailFail");
        private static readonly ILog errorLog = LogManager.GetLogger("ErrorLog");
        private static readonly ILog logLicense = LogManager.GetLogger("LogLicense");


        private readonly IConfiguration _configuration;
        //private readonly string _nasLogLoc;
        //private readonly string _nasErrorLogLoc;
        private readonly string _nasLic;

        public LogService(IConfiguration configuration)
        {
            _configuration = configuration;
            //_nasLogLoc = _configuration.GetSection("NasLogLocation").Value;
            //_nasErrorLogLoc = _configuration.GetSection("ErrorDir").Value;
            _nasLic = _configuration.GetSection("NasLic").Value;
        }


        public void LogLicenseExpired(string message)
        {
            try
            {
                string directory = $"{_nasLic}\\{DateTime.Now.Year}-{DateTime.Now:MM}-{DateTime.Now.Day}.tsv";

                if (File.Exists(directory))
                {
                    return;
                }
                else
                {
                    var logRepository = LogManager.GetRepository(Assembly.GetEntryAssembly());
                    XmlConfigurator.Configure(logRepository, new FileInfo("log4net.config"));

                    string sLogFormat = $"{DateTime.Now}<======>{message} {Environment.NewLine}";
                    logLicense.InfoFormat(sLogFormat);
                }
            }
            catch (Exception e)
            {
                LogError(e.Message);
            }
        }

        private void LogErrorByLog4Net(string errorMessage)
        {
            var logRepository = LogManager.GetRepository(Assembly.GetEntryAssembly());
            XmlConfigurator.Configure(logRepository, new FileInfo("log4net.config"));
            //log.Info(errorMessage);
            //SomeNameLog.DebugFormat("Processing");
            //SummaryLog.DebugFormat("Processing2");
        }

        public void LogSmsSuccess(string filePath, string productId, string accountNo, string sendTo, string message, string status)
        {
            try
            {
                var logRepository = LogManager.GetRepository(Assembly.GetEntryAssembly());
                XmlConfigurator.Configure(logRepository, new FileInfo("log4net.config"));

                string sLogFormat = $"{Convert.ToString(DateTime.Now)}\t{productId}\t{accountNo}\t{sendTo}\t{message}\t{status} {Environment.NewLine}";

                smsSuccess.InfoFormat(sLogFormat);
            }
            catch (Exception e)
            {
                LogError(e.Message);
            }
        }

        public void LogSmsFailed(string filePath, string productId, string accountNo, string sendTo, string message, string status)
        {
            try
            {
                var logRepository = LogManager.GetRepository(Assembly.GetEntryAssembly());
                XmlConfigurator.Configure(logRepository, new FileInfo("log4net.config"));

                string sLogFormat = $"{Convert.ToString(DateTime.Now)}\t{productId}\t{accountNo}\t{sendTo}\t{message}\t{status} {Environment.NewLine}";

                smsFail.InfoFormat(sLogFormat);
            }
            catch (Exception e)
            {
                LogError(e.Message);
            }
        }

        public void LogEmailSuccess(string filePath, string productId, string accountNo, string sendTo, string message, string status)
        {
            try
            {
                var logRepository = LogManager.GetRepository(Assembly.GetEntryAssembly());
                XmlConfigurator.Configure(logRepository, new FileInfo("log4net.config"));

                string sLogFormat = $"{Convert.ToString(DateTime.Now)}\t{productId}\t{accountNo}\t{sendTo}\t{message}\t{status} {Environment.NewLine}";

                emailSuccess.InfoFormat(sLogFormat);
            }
            catch (Exception e)
            {
                LogError(e.Message);
            }
        }

        public void LogEmailFailed(string filePath, string productId, string accountNo, string sendTo, string message, string status)
        {
            try
            {
                var logRepository = LogManager.GetRepository(Assembly.GetEntryAssembly());
                XmlConfigurator.Configure(logRepository, new FileInfo("log4net.config"));

                string sLogFormat = $"{Convert.ToString(DateTime.Now)}\t{productId}\t{accountNo}\t{sendTo}\t{message}\t{status} {Environment.NewLine}";

                emailFail.InfoFormat(sLogFormat);
            }
            catch (Exception e)
            {
                LogError(e.Message);
            }
        }

        public void LogError(string errorMessage)
        {
            try
            {
                var logRepository = LogManager.GetRepository(Assembly.GetEntryAssembly());
                XmlConfigurator.Configure(logRepository, new FileInfo("log4net.config"));

                string sLogFormat = $"{DateTime.Now}<======>{errorMessage} {Environment.NewLine}";

                errorLog.InfoFormat(sLogFormat);
            }
            catch (Exception e)
            {
                Log.Error(e.Message);
            }

        }

    }
}