﻿using System.Threading.Tasks;

namespace NotificationAlertWinService.Repositories
{
    public interface IUltimusConString
    {
        Task<string> GetUltimusConString();
    }
}
