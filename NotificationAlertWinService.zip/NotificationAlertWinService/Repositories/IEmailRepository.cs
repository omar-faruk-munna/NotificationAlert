﻿using Oracle.ManagedDataAccess.Types;
using System;
using System.Threading.Tasks;

namespace NotificationAlertWinService.Repositories
{
    public interface IEmailRepository
    {
        Task SendEmailAsync(OracleClob clob, string toEmail, string accountNo);

        void SendEmailAsync(string clob, string toEmail, string accountNo, string emailSubject, string content, out int sendRes, out string emaiReasonForFail);

        void ServiceStopSendEmailAsync();

    }
}
