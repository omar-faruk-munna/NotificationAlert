﻿using System.Threading.Tasks;

namespace NotificationAlertWinService.Repositories
{
    public interface ILogRepository
    {
        void LogSmsSuccess(string filePath, string productId, string accountNo, string sendTo, string message, string status);
        void LogSmsFailed(string filePath, string productId, string accountNo, string sendTo, string message, string status);
        void LogEmailSuccess(string filePath, string productId, string accountNo, string sendTo, string message, string status);
        void LogEmailFailed(string filePath, string productId, string accountNo, string sendTo, string message, string status);
        void LogError(string errorMessage);
        void LogLicenseExpired(string message);
    }
}
