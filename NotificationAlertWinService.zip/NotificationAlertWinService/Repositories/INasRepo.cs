﻿using System.Threading.Tasks;

namespace NotificationAlertWinService.Repositories
{
    public interface INasRepo
    {
        Task NasAsync1(string dbCon);

        Task NasAsync2(string dbCon);

        Task NasAsync3(string dbCon);
    }
}
