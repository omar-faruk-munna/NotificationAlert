﻿using System.Threading.Tasks;
using System;

namespace NotificationAlertWinService.Repositories
{
    public interface ISmsRepository
    {
        Task UflSmsSendApiAsync(string smsContent, string toNumber, string accountNo);
        //Task SendSmsAsync(string smsContent, string toNumber, string smsOperator, string accountNo, out Int16 sendRes);

        void SendSmsAsync(string smsContent, string toNumber, string smsOperator, string accountNo, out int sendRes, out string smsReasonForFail);

        void SendSmsOnAppShutDown();
    }
}
