using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using NotificationAlertWinService.Repositories;
using NotificationAlertWinService.Services;
using Polly;
using System;

namespace NotificationAlertWinService
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        public void ConfigureServices(IServiceCollection services)
        {
            services.AddControllers();
            services.AddHostedService<Worker>();

            services.AddHttpClient("SslClient", c =>
            {
                c.BaseAddress = new Uri(Configuration.GetSection("SSL_SMS").GetSection("URI").Value);
                c.DefaultRequestHeaders.Add("User-Agent", "HttpClientFactory-Sample");
            });
            //services.AddHttpClient("CustomSslClient", c =>
            //{
            //    c.BaseAddress = new Uri(Configuration.GetSection("SSL_SMS").GetSection("URI").Value);
            //});
            services.AddHttpClient("BankClient", c =>
            {
                c.BaseAddress = new Uri(Configuration.GetValue<string>("WebAPIBaseUrl"));
                c.DefaultRequestHeaders.Add("User-Agent", "HttpClientFactory-Sample");
                //c.DefaultRequestHeaders.Add("Accept", "application/json");
            });

            //services.AddHttpClient("CustomBankClient", c =>
            //{
            //    c.BaseAddress = new Uri(Configuration.GetValue<string>("WebAPIBaseUrl"));
            //    //c.DefaultRequestHeaders.Add("Accept", "application/json");
            //});

            //services.AddHttpClient("XmlClientTest", c =>
            //{
            //    c.BaseAddress = new Uri(Configuration.GetValue<string>("PayBillURL"));
            //    // Account API ContentType
            //    c.DefaultRequestHeaders.Add("Accept", "application/xml");
            //});

            //--------- Retry Configuration --------------
            //services.AddHttpClient("TestClient", c =>
            //{
            //    c.BaseAddress = new Uri(Configuration.GetValue<string>("WebAPIBaseUrl"));
            //    c.DefaultRequestHeaders.Add("User-Agent", "HttpClientFactory-Sample");
            //})
            //.AddTransientHttpErrorPolicy(builder => builder.WaitAndRetryAsync(new[]
            //{
            //    TimeSpan.FromSeconds(1),
            //    TimeSpan.FromSeconds(5),
            //    TimeSpan.FromSeconds(10)
            //}));


            //------ DI ---------------
            services.AddSingleton(Configuration);
            services.AddSingleton<INasRepo, NasRepo>();
            services.AddSingleton<IEmailRepository, EmailService>();
            services.AddSingleton<ISmsRepository, SmsService>();
            services.AddSingleton<ILogRepository, LogService>();
            services.AddSingleton<IUltimusConString, UltimusConString>();

        }

        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseRouting();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapGet("/", async context =>
                {
                    await context.Response.WriteAsync("API Run");
                });
            });
        }
    }
}
