﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using NotificationAlertWinService.Repositories;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace NotificationAlertWinService
{
    public class Worker : BackgroundService
    {
        private static Timer tTimer1 = null;
        private static Timer tTimer2 = null;
        private static Timer tTimer3 = null;
        private readonly IConfiguration _configuration;
        private readonly INasRepo _nasRepo;
        private readonly ILogRepository _errorLog;
        private readonly IUltimusConString _ultimusCon;
        private readonly IEmailRepository _emailRepository;
        private readonly ISmsRepository _smsRepository;
        private readonly int _firstTimeTryPeriod;
        private readonly int _secondTimeTryPeriod;
        private readonly int _thirdTimeTryPeriod;
        private readonly string _dbCon;

        public Worker(IConfiguration configuration, INasRepo nasRepo, ILogRepository errorLog, IUltimusConString ultimusCon, IEmailRepository emailRepository, ISmsRepository smsRepository)
        {
            _configuration = configuration;
            _nasRepo = nasRepo;
            _errorLog = errorLog;
            _ultimusCon = ultimusCon;
            _emailRepository = emailRepository;
            _smsRepository = smsRepository;
            _dbCon = _ultimusCon.GetUltimusConString().Result;
            _firstTimeTryPeriod = Convert.ToInt32(_configuration.GetSection("FirstTimeTryPeriod").Value);
            _secondTimeTryPeriod = Convert.ToInt32(_configuration.GetSection("SecondTimeTryPeriod").Value);
            _thirdTimeTryPeriod = Convert.ToInt32(_configuration.GetSection("ThirdTimeTryPeriod").Value);
        }

        //Every 10 sec
        void TickTimer1(object state)
        {
            try
            {
                Console.WriteLine($"Active Thread {DateTime.Now} {Thread.CurrentThread.ManagedThreadId.ToString()}");
                _nasRepo.NasAsync1(_dbCon).Wait();
            }
            catch (Exception e)
            {
                _errorLog.LogError(e.Message);
            }
        }

        // every 30 min 
        void TickTimer2(object state)
        {
            try
            {
                _nasRepo.NasAsync2(_dbCon).Wait();
            }
            catch (Exception e)
            {
                _errorLog.LogError(e.Message);
            }
        }

        //every 1 hour
        void TickTimer3(object state)
        {
            try
            {
                _nasRepo.NasAsync3(_dbCon).Wait();
            }
            catch (Exception e)
            {
                _errorLog.LogError(e.Message);
            }
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            try
            {
                tTimer1 = new Timer(TickTimer1, null, 0, _firstTimeTryPeriod);
                tTimer2 = new Timer(TickTimer2, null, 0, _secondTimeTryPeriod);
                tTimer3 = new Timer(TickTimer3, null, 0, _thirdTimeTryPeriod);
            }
            catch (Exception e)
            {
                _errorLog.LogError(e.Message);
            }
        }

        public override async Task StopAsync(CancellationToken cancellationToken)
        {
            try
            {
                _smsRepository.SendSmsOnAppShutDown();
                _emailRepository.ServiceStopSendEmailAsync();
                _errorLog.LogError("Stop Function Execute From Worker Process.");
                await Task.Delay(3000);
            }
            catch (Exception e)
            {
                _errorLog.LogError(e.Message);
            }
        }
    }
}
