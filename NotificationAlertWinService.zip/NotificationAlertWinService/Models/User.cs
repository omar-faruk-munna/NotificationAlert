﻿namespace NotificationAlertWinService.Models
{
    public class User
    {
        public string UserId { get; set; }
        public string Password { get; set; }
        public string ConnectionId { get; set; }
    }
}
